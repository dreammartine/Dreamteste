import { useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

interface NewReportProps {
  onBack: () => void;
}

interface ImageFile {
  file: File;
  type: "normal" | "thermal";
  preview: string;
}

export function NewReport({ onBack }: NewReportProps) {
  const [formData, setFormData] = useState({
    companyId: "" as Id<"companies"> | "",
    orderNumber: "",
    assetType: "",
    analysis: "",
    handling: "",
    imageName: "",
    technician: "",
  });
  
  const [images, setImages] = useState<ImageFile[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showNewCompanyForm, setShowNewCompanyForm] = useState(false);
  const [newCompanyName, setNewCompanyName] = useState("");
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const companies = useQuery(api.companies.list);
  const createReport = useMutation(api.reports.create);
  const generateUploadUrl = useMutation(api.reports.generateUploadUrl);
  const addImage = useMutation(api.images.addImage);
  const createCompany = useMutation(api.companies.create);
  const seedCompanies = useMutation(api.companies.seedDefaultCompanies);

  // Seed default companies on first load
  useState(() => {
    if (companies?.length === 0) {
      seedCompanies();
    }
  });

  const classifyImageType = (file: File): "normal" | "thermal" => {
    const fileName = file.name.toLowerCase();
    const thermalKeywords = ["termo", "thermal", "ir", "infra", "flir"];
    
    return thermalKeywords.some(keyword => fileName.includes(keyword)) ? "thermal" : "normal";
  };

  const handleFileUpload = (files: FileList) => {
    const newImages: ImageFile[] = [];
    
    Array.from(files).forEach((file) => {
      if (file.type.startsWith("image/")) {
        const type = classifyImageType(file);
        const preview = URL.createObjectURL(file);
        
        newImages.push({ file, type, preview });
        
        // Auto-fill image name from first file
        if (images.length === 0 && newImages.length === 1) {
          setFormData(prev => ({ ...prev, imageName: file.name }));
        }
      }
    });
    
    setImages(prev => [...prev, ...newImages]);
    
    // Generate automatic suggestions
    if (newImages.length > 0) {
      generateSuggestions();
    }
  };

  const generateSuggestions = () => {
    const defaultAnalysis = "Análise termográfica realizada conforme procedimento. Verificar pontos de aquecimento identificados.";
    const defaultHandling = "Verificar conexões elétricas, aperto de terminais e possível sobrecarga. Repetir leitura se necessário.";
    
    setFormData(prev => ({
      ...prev,
      analysis: prev.analysis || defaultAnalysis,
      handling: prev.handling || defaultHandling,
    }));
  };

  const handleImageTypeChange = (index: number, newType: "normal" | "thermal") => {
    setImages(prev => prev.map((img, i) => i === index ? { ...img, type: newType } : img));
  };

  const removeImage = (index: number) => {
    setImages(prev => {
      const newImages = prev.filter((_, i) => i !== index);
      URL.revokeObjectURL(prev[index].preview);
      return newImages;
    });
  };

  const handleAddCompany = async () => {
    if (!newCompanyName.trim()) return;
    
    try {
      const companyId = await createCompany({ name: newCompanyName.trim() });
      setFormData(prev => ({ ...prev, companyId }));
      setNewCompanyName("");
      setShowNewCompanyForm(false);
      toast.success("Empresa adicionada com sucesso!");
    } catch (error) {
      toast.error("Erro ao adicionar empresa");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.companyId || !formData.orderNumber || images.length === 0) {
      toast.error("Preencha todos os campos obrigatórios e adicione pelo menos uma imagem");
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Create the report
      const reportId = await createReport({
        companyId: formData.companyId as Id<"companies">,
        orderNumber: formData.orderNumber,
        assetType: formData.assetType,
        analysis: formData.analysis,
        handling: formData.handling,
        imageName: formData.imageName,
        technician: formData.technician,
      });
      
      // Upload images
      for (const imageFile of images) {
        const uploadUrl = await generateUploadUrl();
        
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": imageFile.file.type },
          body: imageFile.file,
        });
        
        if (!result.ok) {
          throw new Error("Falha no upload da imagem");
        }
        
        const { storageId } = await result.json();
        
        await addImage({
          reportId,
          type: imageFile.type,
          storageId,
          originalName: imageFile.file.name,
        });
      }
      
      toast.success("Relatório criado com sucesso!");
      onBack();
    } catch (error) {
      toast.error("Erro ao criar relatório");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            ← Voltar
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Novo Relatório</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Company Selection */}
          <div className="bg-white p-6 rounded-2xl shadow-md">
            <h2 className="text-lg font-semibold mb-4">Informações da Empresa</h2>
            
            {!showNewCompanyForm ? (
              <div className="flex gap-3">
                <select
                  value={formData.companyId}
                  onChange={(e) => setFormData(prev => ({ ...prev, companyId: e.target.value as Id<"companies"> }))}
                  className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Selecione uma empresa</option>
                  {companies?.map((company) => (
                    <option key={company._id} value={company._id}>
                      {company.name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setShowNewCompanyForm(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  + Nova
                </button>
              </div>
            ) : (
              <div className="flex gap-3">
                <input
                  type="text"
                  value={newCompanyName}
                  onChange={(e) => setNewCompanyName(e.target.value)}
                  placeholder="Nome da nova empresa"
                  className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={handleAddCompany}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  Adicionar
                </button>
                <button
                  type="button"
                  onClick={() => setShowNewCompanyForm(false)}
                  className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                >
                  Cancelar
                </button>
              </div>
            )}
          </div>

          {/* Basic Information */}
          <div className="bg-white p-6 rounded-2xl shadow-md">
            <h2 className="text-lg font-semibold mb-4">Informações Básicas</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ordem de Serviço (OS) *
                </label>
                <input
                  type="text"
                  value={formData.orderNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, orderNumber: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tipo de Ativo
                </label>
                <input
                  type="text"
                  value={formData.assetType}
                  onChange={(e) => setFormData(prev => ({ ...prev, assetType: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome da Imagem
                </label>
                <input
                  type="text"
                  value={formData.imageName}
                  onChange={(e) => setFormData(prev => ({ ...prev, imageName: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Técnico Responsável
                </label>
                <input
                  type="text"
                  value={formData.technician}
                  onChange={(e) => setFormData(prev => ({ ...prev, technician: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Image Upload */}
          <div className="bg-white p-6 rounded-2xl shadow-md">
            <h2 className="text-lg font-semibold mb-4">Upload de Imagens</h2>
            
            <div
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (e.dataTransfer.files) {
                  handleFileUpload(e.dataTransfer.files);
                }
              }}
            >
              <div className="text-4xl mb-4">📁</div>
              <p className="text-lg font-medium text-gray-700 mb-2">
                Clique ou arraste imagens aqui
              </p>
              <p className="text-sm text-gray-500">
                Suporte para múltiplas imagens (JPG, PNG)
              </p>
            </div>
            
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
              className="hidden"
            />

            {/* Image Preview */}
            {images.length > 0 && (
              <div className="mt-6">
                <h3 className="font-medium text-gray-700 mb-3">Imagens Carregadas ({images.length})</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {images.map((image, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-3">
                      <img
                        src={image.preview}
                        alt={`Preview ${index + 1}`}
                        className="w-full h-32 object-cover rounded-lg mb-3"
                      />
                      <div className="space-y-2">
                        <p className="text-sm font-medium truncate">{image.file.name}</p>
                        <div className="flex gap-2">
                          <select
                            value={image.type}
                            onChange={(e) => handleImageTypeChange(index, e.target.value as "normal" | "thermal")}
                            className="flex-1 text-xs p-2 border border-gray-300 rounded"
                          >
                            <option value="normal">Normal</option>
                            <option value="thermal">Termográfica</option>
                          </select>
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="px-2 py-1 text-xs bg-red-500 text-white rounded hover:bg-red-600"
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Analysis and Handling */}
          <div className="bg-white p-6 rounded-2xl shadow-md">
            <h2 className="text-lg font-semibold mb-4">Análise e Recomendações</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Análise Diagnóstica ou Defeitos
                </label>
                <textarea
                  value={formData.analysis}
                  onChange={(e) => setFormData(prev => ({ ...prev, analysis: e.target.value }))}
                  rows={4}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sugestões de Manuseio
                </label>
                <textarea
                  value={formData.handling}
                  onChange={(e) => setFormData(prev => ({ ...prev, handling: e.target.value }))}
                  rows={4}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={onBack}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? "Salvando..." : "Salvar Relatório"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
