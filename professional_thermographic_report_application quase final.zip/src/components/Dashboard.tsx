import { useState } from "react";
import { NewReport } from "./NewReport";
import { ReportsList } from "./ReportsList";
import { CompaniesManager } from "./CompaniesManager";
import { ReportDetail } from "./ReportDetail";

type View = "dashboard" | "new-report" | "reports" | "companies" | "report-detail";

export function Dashboard() {
  const [currentView, setCurrentView] = useState<View>("dashboard");
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);

  const handleViewReport = (reportId: string) => {
    setSelectedReportId(reportId);
    setCurrentView("report-detail");
  };

  const handleBackToDashboard = () => {
    setCurrentView("dashboard");
    setSelectedReportId(null);
  };

  if (currentView === "new-report") {
    return <NewReport onBack={handleBackToDashboard} />;
  }

  if (currentView === "reports") {
    return <ReportsList onBack={handleBackToDashboard} onViewReport={handleViewReport} />;
  }

  if (currentView === "companies") {
    return <CompaniesManager onBack={handleBackToDashboard} />;
  }

  if (currentView === "report-detail" && selectedReportId) {
    return <ReportDetail reportId={selectedReportId} onBack={() => setCurrentView("reports")} />;
  }

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Dashboard</h1>
          <p className="text-gray-600">Gerencie seus relatórios termográficos</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <DashboardCard
            title="Novo Relatório"
            description="Criar um novo relatório termográfico"
            icon="📊"
            onClick={() => setCurrentView("new-report")}
            className="bg-gradient-to-br from-blue-500 to-blue-600 text-white"
          />
          
          <DashboardCard
            title="Relatórios"
            description="Visualizar e gerenciar relatórios existentes"
            icon="📋"
            onClick={() => setCurrentView("reports")}
            className="bg-gradient-to-br from-green-500 to-green-600 text-white"
          />
          
          <DashboardCard
            title="Empresas"
            description="Gerenciar empresas e filiais"
            icon="🏢"
            onClick={() => setCurrentView("companies")}
            className="bg-gradient-to-br from-purple-500 to-purple-600 text-white"
          />
        </div>

        <div className="mt-12">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Ações Rápidas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <QuickActionCard
              title="Upload em Massa"
              description="Envie várias imagens de uma vez"
              onClick={() => setCurrentView("new-report")}
            />
            <QuickActionCard
              title="Relatórios Recentes"
              description="Acesse os últimos relatórios criados"
              onClick={() => setCurrentView("reports")}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

interface DashboardCardProps {
  title: string;
  description: string;
  icon: string;
  onClick: () => void;
  className?: string;
}

function DashboardCard({ title, description, icon, onClick, className }: DashboardCardProps) {
  return (
    <div
      onClick={onClick}
      className={`p-6 rounded-2xl shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer transform hover:scale-105 ${className}`}
    >
      <div className="text-3xl mb-3">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="opacity-90">{description}</p>
    </div>
  );
}

interface QuickActionCardProps {
  title: string;
  description: string;
  onClick: () => void;
}

function QuickActionCard({ title, description, onClick }: QuickActionCardProps) {
  return (
    <div
      onClick={onClick}
      className="p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer border border-gray-200"
    >
      <h4 className="font-semibold text-gray-800 mb-1">{title}</h4>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  );
}
