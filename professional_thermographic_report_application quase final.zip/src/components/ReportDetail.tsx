import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { useState } from "react";
import { toast } from "sonner";

interface ReportDetailProps {
  reportId: string;
  onBack: () => void;
}

export function ReportDetail({ reportId, onBack }: ReportDetailProps) {
  const report = useQuery(api.reports.get, { id: reportId as Id<"reports"> });
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    orderNumber: "",
    assetType: "",
    analysis: "",
    handling: "",
    imageName: "",
    technician: "",
  });
  
  const updateReport = useMutation(api.reports.update);
  const upsertTechnicalData = useMutation(api.technicalData.upsert);
  
  const [technicalData, setTechnicalData] = useState({
    minTemp: "",
    maxTemp: "",
    avgTemp: "",
    location: "",
    severity: "Baixa" as "Baixa" | "Média" | "Alta",
    observations: "",
  });

  // Initialize edit data when report loads
  useState(() => {
    if (report && !isEditing) {
      setEditData({
        orderNumber: report.orderNumber,
        assetType: report.assetType || "",
        analysis: report.analysis || "",
        handling: report.handling || "",
        imageName: report.imageName || "",
        technician: report.technician || "",
      });
      
      if (report.technicalData) {
        setTechnicalData({
          minTemp: report.technicalData.minTemp?.toString() || "",
          maxTemp: report.technicalData.maxTemp?.toString() || "",
          avgTemp: report.technicalData.avgTemp?.toString() || "",
          location: report.technicalData.location || "",
          severity: report.technicalData.severity || "Baixa",
          observations: report.technicalData.observations || "",
        });
      }
    }
  });

  const handleSave = async () => {
    if (!report) return;
    
    try {
      await updateReport({
        id: report._id,
        orderNumber: editData.orderNumber,
        assetType: editData.assetType,
        analysis: editData.analysis,
        handling: editData.handling,
        imageName: editData.imageName,
        technician: editData.technician,
      });
      
      await upsertTechnicalData({
        reportId: report._id,
        minTemp: technicalData.minTemp ? parseFloat(technicalData.minTemp) : undefined,
        maxTemp: technicalData.maxTemp ? parseFloat(technicalData.maxTemp) : undefined,
        avgTemp: technicalData.avgTemp ? parseFloat(technicalData.avgTemp) : undefined,
        location: technicalData.location || undefined,
        severity: technicalData.severity,
        observations: technicalData.observations || undefined,
      });
      
      setIsEditing(false);
      toast.success("Relatório atualizado com sucesso!");
    } catch (error) {
      toast.error("Erro ao atualizar relatório");
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const groupImagesByPairs = (images: any[]) => {
    const pairs: Array<{ normal?: any; thermal?: any }> = [];
    const normalImages = images.filter(img => img.type === "normal");
    const thermalImages = images.filter(img => img.type === "thermal");
    
    const maxPairs = Math.max(normalImages.length, thermalImages.length);
    
    for (let i = 0; i < maxPairs; i++) {
      pairs.push({
        normal: normalImages[i],
        thermal: thermalImages[i],
      });
    }
    
    return pairs;
  };

  if (report === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!report) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Relatório não encontrado</h2>
          <button
            onClick={onBack}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  const imagePairs = groupImagesByPairs(report.images || []);

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              ← Voltar
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Relatório Termográfico</h1>
              <p className="text-gray-600">OS: {report.orderNumber} - {report.companyName}</p>
            </div>
          </div>
          <div className="flex gap-3">
            {isEditing ? (
              <>
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSave}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Salvar
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setIsEditing(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Editar
                </button>
                <button
                  onClick={() => toast.info("Funcionalidade de exportar PDF em desenvolvimento")}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  Exportar PDF
                </button>
              </>
            )}
          </div>
        </div>

        {/* Report Header Info */}
        <div className="bg-white p-6 rounded-2xl shadow-md mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <h3 className="font-semibold text-gray-700 mb-2">Informações Básicas</h3>
              <div className="space-y-1 text-sm">
                <p><span className="font-medium">Empresa:</span> {report.companyName}</p>
                <p><span className="font-medium">OS:</span> {report.orderNumber}</p>
                <p><span className="font-medium">Data:</span> {formatDate(report.createdAt)}</p>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-700 mb-2">Detalhes do Ativo</h3>
              <div className="space-y-1 text-sm">
                {isEditing ? (
                  <input
                    type="text"
                    value={editData.assetType}
                    onChange={(e) => setEditData(prev => ({ ...prev, assetType: e.target.value }))}
                    placeholder="Tipo de Ativo"
                    className="w-full p-2 border border-gray-300 rounded text-sm"
                  />
                ) : (
                  <p><span className="font-medium">Tipo:</span> {report.assetType || "Não informado"}</p>
                )}
                <p><span className="font-medium">Imagens:</span> {report.images?.length || 0}</p>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-700 mb-2">Responsável</h3>
              <div className="space-y-1 text-sm">
                {isEditing ? (
                  <input
                    type="text"
                    value={editData.technician}
                    onChange={(e) => setEditData(prev => ({ ...prev, technician: e.target.value }))}
                    placeholder="Técnico Responsável"
                    className="w-full p-2 border border-gray-300 rounded text-sm"
                  />
                ) : (
                  <p><span className="font-medium">Técnico:</span> {report.technician || "Não informado"}</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Image Pairs */}
        {imagePairs.map((pair, index) => (
          <div key={index} className="bg-white p-6 rounded-2xl shadow-md mb-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              Página {index + 1}
              {isEditing && index === 0 && (
                <input
                  type="text"
                  value={editData.imageName}
                  onChange={(e) => setEditData(prev => ({ ...prev, imageName: e.target.value }))}
                  placeholder="Nome da imagem"
                  className="ml-4 p-2 border border-gray-300 rounded text-sm"
                />
              )}
            </h3>
            
            {/* Images Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Normal Image */}
              <div>
                <h4 className="font-medium text-gray-700 mb-2">Foto Normal</h4>
                {pair.normal ? (
                  <div className="relative group">
                    <img
                      src={pair.normal.url}
                      alt="Foto Normal"
                      className="w-full h-64 object-cover rounded-lg border border-gray-200 group-hover:scale-105 transition-transform duration-200"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-200 rounded-lg"></div>
                  </div>
                ) : (
                  <div className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                    <span className="text-gray-500">Imagem não disponível</span>
                  </div>
                )}
              </div>

              {/* Thermal Image */}
              <div>
                <h4 className="font-medium text-gray-700 mb-2">Foto Termográfica</h4>
                {pair.thermal ? (
                  <div className="relative group">
                    <img
                      src={pair.thermal.url}
                      alt="Foto Termográfica"
                      className="w-full h-64 object-cover rounded-lg border border-gray-200 group-hover:scale-105 transition-transform duration-200"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-200 rounded-lg"></div>
                  </div>
                ) : (
                  <div className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                    <span className="text-gray-500">Imagem não disponível</span>
                  </div>
                )}
              </div>
            </div>

            {/* Analysis Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="bg-blue-50 p-4 rounded-xl">
                <h4 className="font-semibold text-blue-800 mb-2">Análise Diagnóstica</h4>
                {isEditing ? (
                  <textarea
                    value={editData.analysis}
                    onChange={(e) => setEditData(prev => ({ ...prev, analysis: e.target.value }))}
                    rows={4}
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                  />
                ) : (
                  <p className="text-blue-700 text-sm">{report.analysis || "Não informado"}</p>
                )}
              </div>
              
              <div className="bg-green-50 p-4 rounded-xl">
                <h4 className="font-semibold text-green-800 mb-2">Sugestões de Manuseio</h4>
                {isEditing ? (
                  <textarea
                    value={editData.handling}
                    onChange={(e) => setEditData(prev => ({ ...prev, handling: e.target.value }))}
                    rows={4}
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                  />
                ) : (
                  <p className="text-green-700 text-sm">{report.handling || "Não informado"}</p>
                )}
              </div>
            </div>

            {/* Technical Data Table */}
            <div className="bg-gray-50 p-4 rounded-xl">
              <h4 className="font-semibold text-gray-800 mb-3">Dados Técnicos</h4>
              {isEditing ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Temp. Mín (°C)</label>
                    <input
                      type="number"
                      value={technicalData.minTemp}
                      onChange={(e) => setTechnicalData(prev => ({ ...prev, minTemp: e.target.value }))}
                      className="w-full p-2 border border-gray-300 rounded text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Temp. Máx (°C)</label>
                    <input
                      type="number"
                      value={technicalData.maxTemp}
                      onChange={(e) => setTechnicalData(prev => ({ ...prev, maxTemp: e.target.value }))}
                      className="w-full p-2 border border-gray-300 rounded text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Temp. Média (°C)</label>
                    <input
                      type="number"
                      value={technicalData.avgTemp}
                      onChange={(e) => setTechnicalData(prev => ({ ...prev, avgTemp: e.target.value }))}
                      className="w-full p-2 border border-gray-300 rounded text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Localização</label>
                    <input
                      type="text"
                      value={technicalData.location}
                      onChange={(e) => setTechnicalData(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full p-2 border border-gray-300 rounded text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Severidade</label>
                    <select
                      value={technicalData.severity}
                      onChange={(e) => setTechnicalData(prev => ({ ...prev, severity: e.target.value as "Baixa" | "Média" | "Alta" }))}
                      className="w-full p-2 border border-gray-300 rounded text-sm"
                    >
                      <option value="Baixa">Baixa</option>
                      <option value="Média">Média</option>
                      <option value="Alta">Alta</option>
                    </select>
                  </div>
                  <div className="md:col-span-3">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Observações</label>
                    <textarea
                      value={technicalData.observations}
                      onChange={(e) => setTechnicalData(prev => ({ ...prev, observations: e.target.value }))}
                      rows={2}
                      className="w-full p-2 border border-gray-300 rounded text-sm"
                    />
                  </div>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-300">
                        <th className="text-left py-2 px-3">Temp. Mín</th>
                        <th className="text-left py-2 px-3">Temp. Máx</th>
                        <th className="text-left py-2 px-3">Temp. Média</th>
                        <th className="text-left py-2 px-3">Localização</th>
                        <th className="text-left py-2 px-3">Severidade</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="py-2 px-3">{report.technicalData?.minTemp ? `${report.technicalData.minTemp}°C` : "-"}</td>
                        <td className="py-2 px-3">{report.technicalData?.maxTemp ? `${report.technicalData.maxTemp}°C` : "-"}</td>
                        <td className="py-2 px-3">{report.technicalData?.avgTemp ? `${report.technicalData.avgTemp}°C` : "-"}</td>
                        <td className="py-2 px-3">{report.technicalData?.location || "-"}</td>
                        <td className="py-2 px-3">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            report.technicalData?.severity === "Alta" ? "bg-red-100 text-red-800" :
                            report.technicalData?.severity === "Média" ? "bg-yellow-100 text-yellow-800" :
                            "bg-green-100 text-green-800"
                          }`}>
                            {report.technicalData?.severity || "Baixa"}
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  {report.technicalData?.observations && (
                    <div className="mt-3 p-3 bg-white rounded border">
                      <p className="text-sm"><span className="font-medium">Observações:</span> {report.technicalData.observations}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
