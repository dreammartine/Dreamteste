import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

interface ReportsListProps {
  onBack: () => void;
  onViewReport: (reportId: string) => void;
}

export function ReportsList({ onBack, onViewReport }: ReportsListProps) {
  const reports = useQuery(api.reports.list, {});
  const companies = useQuery(api.companies.list);
  const deleteReport = useMutation(api.reports.remove);

  const handleDeleteReport = async (reportId: Id<"reports">, orderNumber: string) => {
    if (window.confirm(`Tem certeza que deseja excluir o relatório OS: ${orderNumber}? Esta ação não pode ser desfeita.`)) {
      try {
        await deleteReport({ id: reportId });
        toast.success("Relatório excluído com sucesso!");
      } catch (error) {
        toast.error("Erro ao excluir relatório");
      }
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (reports === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            ← Voltar
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Relatórios</h1>
        </div>

        {reports.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📋</div>
            <h2 className="text-xl font-semibold text-gray-700 mb-2">Nenhum relatório encontrado</h2>
            <p className="text-gray-500">Crie seu primeiro relatório para começar</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reports.map((report) => (
              <div key={report._id} className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-200">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-1">OS: {report.orderNumber}</h3>
                      <p className="text-sm text-gray-600">{report.companyName}</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => onViewReport(report._id)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Visualizar"
                      >
                        👁️
                      </button>
                      <button
                        onClick={() => handleDeleteReport(report._id, report.orderNumber)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Excluir"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    {report.assetType && (
                      <p className="text-sm">
                        <span className="font-medium">Ativo:</span> {report.assetType}
                      </p>
                    )}
                    {report.technician && (
                      <p className="text-sm">
                        <span className="font-medium">Técnico:</span> {report.technician}
                      </p>
                    )}
                    <p className="text-sm">
                      <span className="font-medium">Imagens:</span> {report.imageCount}
                    </p>
                  </div>
                  
                  <div className="text-xs text-gray-500 mb-4">
                    Criado em {formatDate(report.createdAt)}
                  </div>
                  
                  {report.analysis && (
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-700 line-clamp-3">
                        {report.analysis}
                      </p>
                    </div>
                  )}
                </div>
                
                <div className="px-6 pb-6">
                  <button
                    onClick={() => onViewReport(report._id)}
                    className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Ver Detalhes
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
