import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface CompaniesManagerProps {
  onBack: () => void;
}

export function CompaniesManager({ onBack }: CompaniesManagerProps) {
  const [newCompanyName, setNewCompanyName] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  
  const companies = useQuery(api.companies.list);
  const createCompany = useMutation(api.companies.create);
  const seedCompanies = useMutation(api.companies.seedDefaultCompanies);

  const handleAddCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newCompanyName.trim()) {
      toast.error("Nome da empresa é obrigatório");
      return;
    }
    
    setIsAdding(true);
    
    try {
      await createCompany({ name: newCompanyName.trim() });
      setNewCompanyName("");
      toast.success("Empresa adicionada com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao adicionar empresa");
    } finally {
      setIsAdding(false);
    }
  };

  const handleSeedCompanies = async () => {
    try {
      await seedCompanies();
      toast.success("Empresas padrão adicionadas!");
    } catch (error) {
      toast.error("Erro ao adicionar empresas padrão");
    }
  };

  if (companies === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            ← Voltar
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Gerenciar Empresas</h1>
        </div>

        {/* Add New Company */}
        <div className="bg-white p-6 rounded-2xl shadow-md mb-6">
          <h2 className="text-lg font-semibold mb-4">Adicionar Nova Empresa</h2>
          <form onSubmit={handleAddCompany} className="flex gap-3">
            <input
              type="text"
              value={newCompanyName}
              onChange={(e) => setNewCompanyName(e.target.value)}
              placeholder="Nome da empresa"
              className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={isAdding}
            />
            <button
              type="submit"
              disabled={isAdding || !newCompanyName.trim()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAdding ? "Adicionando..." : "Adicionar"}
            </button>
          </form>
          
          {companies.length === 0 && (
            <div className="mt-4">
              <button
                onClick={handleSeedCompanies}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
              >
                Adicionar Empresas Padrão
              </button>
            </div>
          )}
        </div>

        {/* Companies List */}
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-lg font-semibold mb-4">Empresas Cadastradas ({companies.length})</h2>
          
          {companies.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-4">🏢</div>
              <p className="text-gray-600">Nenhuma empresa cadastrada</p>
              <p className="text-sm text-gray-500 mt-2">
                Adicione uma nova empresa ou use as empresas padrão
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {companies.map((company) => (
                <div
                  key={company._id}
                  className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <span className="text-blue-600 font-semibold">
                        {company.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-800">{company.name}</h3>
                      <p className="text-sm text-gray-500">
                        {company.active ? "Ativa" : "Inativa"}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
