import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {
    companyId: v.optional(v.id("companies")),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    let reports;
    
    if (args.companyId) {
      reports = await ctx.db
        .query("reports")
        .withIndex("by_company", (q) => q.eq("companyId", args.companyId!))
        .order("desc")
        .take(args.limit || 50);
    } else {
      reports = await ctx.db
        .query("reports")
        .order("desc")
        .take(args.limit || 50);
    }

    // Get company names and image counts for each report
    const reportsWithDetails = await Promise.all(
      reports.map(async (report) => {
        const company = await ctx.db.get(report.companyId);
        const images = await ctx.db
          .query("images")
          .withIndex("by_report", (q) => q.eq("reportId", report._id))
          .collect();
        
        return {
          ...report,
          companyName: company?.name || "Empresa não encontrada",
          imageCount: images.length,
        };
      })
    );

    return reportsWithDetails;
  },
});

export const get = query({
  args: { id: v.id("reports") },
  handler: async (ctx, args) => {
    const report = await ctx.db.get(args.id);
    if (!report) return null;

    const company = await ctx.db.get(report.companyId);
    const images = await ctx.db
      .query("images")
      .withIndex("by_report", (q) => q.eq("reportId", args.id))
      .collect();

    // Get URLs for images
    const imagesWithUrls = await Promise.all(
      images.map(async (image) => ({
        ...image,
        url: await ctx.storage.getUrl(image.storageId),
      }))
    );

    const technicalData = await ctx.db
      .query("technicalData")
      .withIndex("by_report", (q) => q.eq("reportId", args.id))
      .first();

    return {
      ...report,
      companyName: company?.name || "Empresa não encontrada",
      images: imagesWithUrls,
      technicalData,
    };
  },
});

export const create = mutation({
  args: {
    companyId: v.id("companies"),
    orderNumber: v.string(),
    assetType: v.string(),
    analysis: v.string(),
    handling: v.string(),
    imageName: v.string(),
    technician: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("reports", {
      ...args,
      createdAt: Date.now(),
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("reports"),
    companyId: v.optional(v.id("companies")),
    orderNumber: v.optional(v.string()),
    assetType: v.optional(v.string()),
    analysis: v.optional(v.string()),
    handling: v.optional(v.string()),
    imageName: v.optional(v.string()),
    technician: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { id, ...updates } = args;
    const filteredUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );
    
    return await ctx.db.patch(id, filteredUpdates);
  },
});

export const remove = mutation({
  args: { id: v.id("reports") },
  handler: async (ctx, args) => {
    // Delete all associated images first
    const images = await ctx.db
      .query("images")
      .withIndex("by_report", (q) => q.eq("reportId", args.id))
      .collect();

    for (const image of images) {
      await ctx.storage.delete(image.storageId);
      await ctx.db.delete(image._id);
    }

    // Delete technical data
    const technicalData = await ctx.db
      .query("technicalData")
      .withIndex("by_report", (q) => q.eq("reportId", args.id))
      .first();
    
    if (technicalData) {
      await ctx.db.delete(technicalData._id);
    }

    // Delete the report
    await ctx.db.delete(args.id);
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
