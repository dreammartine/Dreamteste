import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

export const upsert = mutation({
  args: {
    reportId: v.id("reports"),
    minTemp: v.optional(v.number()),
    maxTemp: v.optional(v.number()),
    avgTemp: v.optional(v.number()),
    location: v.optional(v.string()),
    severity: v.optional(v.union(v.literal("Baixa"), v.literal("Média"), v.literal("Alta"))),
    observations: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("technicalData")
      .withIndex("by_report", (q) => q.eq("reportId", args.reportId))
      .first();

    const { reportId, ...data } = args;
    const filteredData = Object.fromEntries(
      Object.entries(data).filter(([_, value]) => value !== undefined)
    );

    if (existing) {
      return await ctx.db.patch(existing._id, filteredData);
    } else {
      return await ctx.db.insert("technicalData", { reportId, ...filteredData });
    }
  },
});

export const getByReport = query({
  args: { reportId: v.id("reports") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("technicalData")
      .withIndex("by_report", (q) => q.eq("reportId", args.reportId))
      .first();
  },
});
