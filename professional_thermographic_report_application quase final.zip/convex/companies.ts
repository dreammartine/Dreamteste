import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("companies")
      .filter((q) => q.eq(q.field("active"), true))
      .order("asc")
      .collect();
  },
});

export const create = mutation({
  args: {
    name: v.string(),
  },
  handler: async (ctx, args) => {
    // Check if company already exists
    const existing = await ctx.db
      .query("companies")
      .withIndex("by_name", (q) => q.eq("name", args.name))
      .first();
    
    if (existing) {
      throw new Error("Empresa já existe");
    }

    return await ctx.db.insert("companies", {
      name: args.name,
      active: true,
    });
  },
});

export const seedDefaultCompanies = mutation({
  args: {},
  handler: async (ctx) => {
    const defaultCompanies = [
      "GREIF MANAUS",
      "GREIF BAHIA", 
      "GREIF RIO DE JANEIRO",
      "Greif Araucária",
      "Greif LONDRINA",
      "Greif ESTEIO",
      "GREIF S.A PLASTICO",
      "GREIF S.A AÇO",
      "GREIF CAMBUI",
      "Greif Paulina"
    ];

    for (const companyName of defaultCompanies) {
      const existing = await ctx.db
        .query("companies")
        .withIndex("by_name", (q) => q.eq("name", companyName))
        .first();
      
      if (!existing) {
        await ctx.db.insert("companies", {
          name: companyName,
          active: true,
        });
      }
    }
  },
});
