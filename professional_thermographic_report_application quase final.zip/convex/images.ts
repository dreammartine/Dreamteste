import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

export const addImage = mutation({
  args: {
    reportId: v.id("reports"),
    type: v.union(v.literal("normal"), v.literal("thermal")),
    storageId: v.id("_storage"),
    originalName: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("images", args);
  },
});

export const getByReport = query({
  args: { reportId: v.id("reports") },
  handler: async (ctx, args) => {
    const images = await ctx.db
      .query("images")
      .withIndex("by_report", (q) => q.eq("reportId", args.reportId))
      .collect();

    return await Promise.all(
      images.map(async (image) => ({
        ...image,
        url: await ctx.storage.getUrl(image.storageId),
      }))
    );
  },
});

export const updateType = mutation({
  args: {
    id: v.id("images"),
    type: v.union(v.literal("normal"), v.literal("thermal")),
  },
  handler: async (ctx, args) => {
    return await ctx.db.patch(args.id, { type: args.type });
  },
});

export const remove = mutation({
  args: { id: v.id("images") },
  handler: async (ctx, args) => {
    const image = await ctx.db.get(args.id);
    if (image) {
      await ctx.storage.delete(image.storageId);
      await ctx.db.delete(args.id);
    }
  },
});
