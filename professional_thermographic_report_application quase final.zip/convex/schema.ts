import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  companies: defineTable({
    name: v.string(),
    active: v.boolean(),
  }).index("by_name", ["name"]),

  reports: defineTable({
    companyId: v.id("companies"),
    orderNumber: v.string(),
    assetType: v.string(),
    analysis: v.string(),
    handling: v.string(),
    imageName: v.string(),
    technician: v.string(),
    createdAt: v.number(),
  }).index("by_company", ["companyId"])
    .index("by_created_at", ["createdAt"]),

  images: defineTable({
    reportId: v.id("reports"),
    type: v.union(v.literal("normal"), v.literal("thermal")),
    storageId: v.id("_storage"),
    originalName: v.string(),
    url: v.optional(v.string()),
  }).index("by_report", ["reportId"])
    .index("by_report_and_type", ["reportId", "type"]),

  technicalData: defineTable({
    reportId: v.id("reports"),
    minTemp: v.optional(v.number()),
    maxTemp: v.optional(v.number()),
    avgTemp: v.optional(v.number()),
    location: v.optional(v.string()),
    severity: v.optional(v.union(v.literal("Baixa"), v.literal("Média"), v.literal("Alta"))),
    observations: v.optional(v.string()),
  }).index("by_report", ["reportId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
